package com.me.ricochetRobots.model.block;

import com.badlogic.gdx.math.Vector2;
import com.me.ricochetRobots.model.ListColor;
import com.me.ricochetRobots.model.ListForm;

public class ObjectifBlock extends Block {

    public ObjectifBlock(Vector2 pos, ListForm listForm, ListColor listColor) {
	super(pos, 2, ListColor.PURPLE, "images/block_" + listForm.getValeur() + "_" + listColor.getValeur() + ".png");
    }

}
