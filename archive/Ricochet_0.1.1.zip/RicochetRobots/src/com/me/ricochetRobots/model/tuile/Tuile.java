package com.me.ricochetRobots.model.tuile;

import com.badlogic.gdx.math.Vector2;
import com.me.ricochetRobots.model.ListColor;
import com.me.ricochetRobots.model.block.Block;

public class Tuile extends Block {
    
    public Tuile(Vector2 pos, ListColor color, String pathImage) {
	super(pos, 1, color, pathImage);
    }
}
