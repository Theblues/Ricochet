package com.me.ricochetRobots.model.tuile;

import com.badlogic.gdx.math.Vector2;
import com.me.ricochetRobots.model.ListColor;
import com.me.ricochetRobots.model.ListForm;

public class TuileObjectif extends Tuile {

    protected ListForm form;
    
    public TuileObjectif(Vector2 pos, ListColor color, ListForm form) {
	super(pos, color, "images/block_" + form.getValeur() + "_" + color.getValeur() + ".png");
	this.form = form;
    }

}
