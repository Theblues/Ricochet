package com.me.ricochetRobots.model;

import com.badlogic.gdx.math.Vector2;
import com.me.ricochetRobots.model.block.Block;

public class Mur extends Block{

    public Mur(Vector2 pos, float width, float height) {
	super(pos, width, height, ListColor.PURPLE, "images/wall.png");
    }

}
