package com.me.ricochetRobots.model.block;

import com.badlogic.gdx.math.Vector2;
import com.me.ricochetRobots.model.ListColor;

public class GameBlock extends Block {

    public GameBlock(Vector2 pos) {
	super(pos, 1, ListColor.WHITE, "images/gameblock.png");
    }

    @Override
    public String toString() {
	return "GameBlock [position=" + position + ", bounds=" + bounds + "]";
    }

}
