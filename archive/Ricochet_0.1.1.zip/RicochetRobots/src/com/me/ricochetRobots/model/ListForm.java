package com.me.ricochetRobots.model;

public enum ListForm {

    CARRE("carre"), CROIX("croix"), TRIANGLE("triangle"), PENTAGONE("pentagone"), OTHER(
	    "multi");

    private String valeur;

    ListForm(String valeur) {
	this.valeur = valeur;
    }

    public String getValeur() {
	return valeur;
    }
}
