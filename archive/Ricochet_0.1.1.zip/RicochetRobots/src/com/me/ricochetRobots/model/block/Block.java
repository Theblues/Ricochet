package com.me.ricochetRobots.model.block;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.me.ricochetRobots.model.ListColor;
import com.me.ricochetRobots.model.Mur;

@SuppressWarnings("rawtypes")
public abstract class Block implements Comparable {
    protected Texture texture;
    protected Vector2 position;
    protected Rectangle bounds;
    protected Array<Mur> murs;
    // temporaire
    protected ListColor color;

    public Block(Vector2 pos, float width, float height, ListColor color,
	    String pathImage) {
	this.position = pos;
	bounds = new Rectangle();
	bounds.width = width;
	bounds.height = height;
	this.color = color;
	if (pathImage == "")
	    texture = null;
	else
	    texture = new Texture(Gdx.files.internal(pathImage));
    }

    public Block(Vector2 pos, float size, ListColor color, String pathImage) {
	this(pos, size, size, color, pathImage);
    }

    public Vector2 getPosition() {
	return position;
    }

    public Rectangle getBounds() {
	return bounds;
    }

    public Texture getTexture() {
	return texture;
    }

    public Color getColor() {
	return color.getColor();
    }

    @Override
    public int compareTo(Object o) {
	Block block = (Block) o;

	if (block.getBounds().width == bounds.width
		&& block.getBounds().height == bounds.height
		&& block.getPosition().x == position.x
		&& block.getPosition().y == position.y
		&& block.getColor().equals(color.getColor()))
	    return 0;
	return -1;
    }
}
