package com.me.ricochetRobots.model;

import java.util.Random;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.me.ricochetRobots.model.block.Block;
import com.me.ricochetRobots.model.block.GameBlock;
import com.me.ricochetRobots.model.block.ObjectifBlock;
import com.me.ricochetRobots.model.tuile.TuileObjectif;

public class World {
    public static final float SIZE_PLATEAU = 18;

    /** The blocks making up the world **/
    protected Array<Block> world;
    private Random r;

    public World() {
	world = new Array<Block>();
	r = new Random();
	createWorld();
    }

    private void createWorld() {
	createBlocks();
	createMiddle();
	initTuileObjectif();
	initWall();
    }

    private void createBlocks() {
	for (float i = 0f; i < SIZE_PLATEAU; i++)
	    for (float j = 0f; j < SIZE_PLATEAU; j++)
		world.add(new GameBlock(new Vector2(i, j)));
    }

    private void createMiddle() {
	float size = SIZE_PLATEAU / 2f;
	// delete all middle gameblock
	Array<Block> delBlocks = new Array<Block>();
	delBlocks.add(new GameBlock(new Vector2(size - 1f, size - 1)));
	delBlocks.add(new GameBlock(new Vector2(size, size - 1)));
	delBlocks.add(new GameBlock(new Vector2(size - 1f, size)));
	delBlocks.add(new GameBlock(new Vector2(size, size)));

	for (Block delBlock : delBlocks)
	    for (Block block : world)
		if (block.compareTo(delBlock) == 0)
		    world.removeValue(block, true);

	// add one objectif block
	int rColor;
	int rForm;
	do {
	    rColor = r.nextInt(ListColor.values().length);
	    rForm = r.nextInt(ListForm.values().length);
	} while (rColor > 4);
	ListColor[] listColor = ListColor.values();
	ListForm[] listForm = ListForm.values();
	world.add(new ObjectifBlock(new Vector2(size - 1f, size - 1f),
		listForm[rForm], listColor[rColor]));
    }

    /*
     * on cree nos tuiles
     */
    private void initTuileObjectif() {
	int i = -1;
	Block delBlock;

	// on parcours les couleurs puis les formes
	for (ListColor color : ListColor.values()) {
	    if (color != ListColor.BLACK && color != ListColor.WHITE
		    && color != ListColor.PURPLE) {
		for (ListForm form : ListForm.values()) {
		    if (form != ListForm.OTHER) {
			// on choisi un bloc aleatoirement
			do {
			    i = r.nextInt(world.size);
			    delBlock = world.get(i);
			} while (delBlock.getColor() != ListColor.WHITE
				.getColor());
			// on supprime ce bloc
			world.removeIndex(i);
			// on cree notre nouveau bloc
			world.add(new TuileObjectif(new Vector2(delBlock
				.getPosition().x, delBlock.getPosition().y),
				color, form));
		    }
		}
	    }
	}
	// on cree notre piece special
	do {
	    i = r.nextInt(world.size);
	    delBlock = world.get(i);
	} while (delBlock.getColor() != ListColor.WHITE.getColor());
	// on supprime ce bloc
	world.removeIndex(i);
	world.add(new TuileObjectif(new Vector2(delBlock.getPosition().x,
		delBlock.getPosition().y), ListColor.BLACK, ListForm.OTHER));
    }

    private void initWall() {
	initWallBorder();
	// / TODO le reste des murs
    }

    private void initWallBorder() {
	for (float i = 0f; i < SIZE_PLATEAU; i++) {
	    for (float j = 0f; j < SIZE_PLATEAU; j++) {
		if (i == 0f)
		    world.add(new Mur(new Vector2(i, j), 0.1f, 1f));
		if (i == SIZE_PLATEAU - 1f)
		    world.add(new Mur(new Vector2(i + 1f, j), -0.1f, 1f));
		if (j == 0f)
		    world.add(new Mur(new Vector2(i, j), 1f, 0.1f));
		if (j == SIZE_PLATEAU - 1f)
		    world.add(new Mur(new Vector2(i, j + 1f), 1f, -0.1f));
		if (i == (SIZE_PLATEAU / 2f - 1f)
			&& j == (SIZE_PLATEAU / 2f - 1f)) {
		    world.add(new Mur(new Vector2(i, j), 0.1f, 1f));
		    world.add(new Mur(new Vector2(i, j), 1f, 0.1f));
		}
		if (i == (SIZE_PLATEAU / 2f - 1f)
			&& j == (SIZE_PLATEAU / 2f + 1)) {
		    world.add(new Mur(new Vector2(i, j), 0.1f, -1f));
		    world.add(new Mur(new Vector2(i, j), 1f, -0.1f));
		}
		if (i == (SIZE_PLATEAU / 2f + 1f)
			&& j == (SIZE_PLATEAU / 2f - 1)) {
		    world.add(new Mur(new Vector2(i, j), -0.1f, 1f));
		    world.add(new Mur(new Vector2(i, j), -1f, 0.1f));
		}
		if (i == (SIZE_PLATEAU / 2f + 1f)
			&& j == (SIZE_PLATEAU / 2f + 1)) {
		    world.add(new Mur(new Vector2(i, j), -0.1f, -1f));
		    world.add(new Mur(new Vector2(i, j), -1f, -0.1f));
		}
	    }
	}
    }

    public Array<Block> getWorld() {
	return world;
    }
}
